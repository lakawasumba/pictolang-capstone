package com.example.pictolangapp.ui.challenge

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.pictolangapp.R

class SkorActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_skor)
    }
}